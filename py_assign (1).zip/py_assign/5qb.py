color=['red','Green', "White",'Black', 'Pink', 'Yellow']
color[color.index("Black")]="Purple"; color[color.index("Pink")]="Purple"
print(color)