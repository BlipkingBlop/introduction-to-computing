color=['red','Green', "White",'Black', 'Pink', 'Yellow']
color.pop(3)
print(color)