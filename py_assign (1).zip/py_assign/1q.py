#program to find average of 3 numbers!!

num1=float(input("Enter 1st number: "))
num2=float(input("Enter 2nd number: "))
num3=float(input("Enter 3rd number: "))

avg=((num1+num2+num3)/3)

print("The average of", num1, num2,num3, "is", avg)