mlist=[]
for i in range (5):
    mark=float(input("Enter mark of Student:" ))
    mlist.append(mark)
    



mlist.sort()

print(mlist)


