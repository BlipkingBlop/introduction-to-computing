sid=input("Enter SID: ")
name=input("Enter name: ")

gender=input("Enter Gender(M,F,U for unknown)")

course=input("Enter course name: ")
cgpa=float(input("Enter CGPA"))

student=[sid,name,gender,course,cgpa]

print(student)
